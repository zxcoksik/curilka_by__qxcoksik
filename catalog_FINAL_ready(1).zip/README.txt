ГОТОВЫЙ КАТАЛОГ ДЛЯ HTMLPREVIEW

Структура:
index.html
assets/css/style.css
assets/js/app.js
assets/js/products.js
assets/images/

ФОТО:
Фото уже переименованы по артикулам.
Например:
assets/images/00046.webp

Чтобы добавить новое фото:
1. Преобразуй его в WEBP.
2. Назови по артикулу товара.
3. Положи в assets/images/.
4. Загрузи файл в GitHub.
5. HTMLPreview автоматически покажет его.

URL:
https://htmlpreview.github.io/?https://github.com/ТВОЙ_НИК/ТВОЙ_РЕПОЗИТОРИЙ/blob/main/index.html

Важно: в GitHub должен лежать именно index.html в корне репозитория.
